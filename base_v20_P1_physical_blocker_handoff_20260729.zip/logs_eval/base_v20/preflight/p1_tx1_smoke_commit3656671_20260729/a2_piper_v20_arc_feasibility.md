# A2 Piper base v20 P1 arc feasibility

Status: **FAIL**

| Mode | Target rad | Feasible | Result |
|---|---:|---:|---|
| F1 | 0.9 | 0/4 | FAIL |

Frozen values:

```json
null
```

# base_v20_R1 scientific manifest

- status: STATIC PASS
- plan: base_v20_R1_policy_behavior_v1
- plan SHA256: 6827290631feea15497fe76cd64116c30a1343d5bd6c1cb83ba09c35bc247e3c
- Hydra configs resolved: 8
